<h1>sbad</h1>
<?php echo e($some); ?>