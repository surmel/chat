<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link href="css/style.css" rel="stylesheet">
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>
        </script>   
    </head>
    <body>          
        <div class="confirm_layer">
            <div class="confirm">
                <p class="question">Are You Sure?</p>
                <span class="yesorno" alt="yes" style="margin-left:0px;">Yes</span>
                <span class="yesorno" alt="no">No</span>
            </div>
        </div>
        <div class="pleasewait">
            <img src="images/wait.gif" class="wait_img">
        </div>
        <div class="link_layer">
            <div id="copyLink">
                <h4>Copy Link</h4>
                <div class="form-group">
                    <input type="text" name="link_input" class="form-control" id="link_input" readonly>
                </div>                        
            </div>
        </div>
        
        <div class="container-fluid nopadding">
            <div class="rooms">
                <p class="room_title">Rooms</p>
                <div class="choose_room">
                    <ul class="room_ul">                        
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if(Auth::user() || Session::has('guest_id')): ?>
                                <li class="room_li" name="<?php echo e($room->id); ?>">
                                
                                    <?php echo e($room->room_name); ?>                                    
                                    <?php if(!Auth::guest() && Auth::user()->id == $room->creator_id): ?> 
                                        <?php if($room->link != ""): ?>
                                            <img src="/images/link.png" class="link_img" name="<?php echo e($room->id); ?>">
                                        <?php endif; ?>
                                        <img src="/images/delete.png" class="del_img" name="<?php echo e($room->id); ?>">                                        
                                    <?php endif; ?>                                    
                                </li>
                            <?php else: ?>
                            <li class="room_li  disabled_li" name="<?php echo e($room->id); ?>">
                                <?php echo e($room->room_name); ?>

                                <?php if(!Auth::guest() && Auth::user()->id == $room->creator_id): ?>
                                    <img src="/images/delete.png" class="del_img" name="<?php echo e($room->id); ?>">
                                <?php endif; ?>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="top_section">
                <div class="room_name">
                    <?php if(isset($data)): ?>
                        Room Name: <?php echo e($data['room_info']->room_name); ?>

                    <?php endif; ?>
                </div>
                <?php if(Auth::guest()): ?>
                    <div class="top-right links">
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    </div>               
                <?php else: ?>
                    <div class="dropdown position">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?>

                        <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                            <li class="dropdown">
                                <a href="#" data-toggle="modal" data-target="#addRoom">Add Room</a>
                            </li>
                            <li class="divider"></li>
                            <li class="dropdown">
                                <a href="<?php echo e(url('/logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>
                            </li>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="content">
                <?php if(Session::has('error')): ?>       
                    <div class="alert alert-danger errors">
                        <strong>Warning!</strong> <?php echo session('error'); ?>

                    </div>        
                <?php endif; ?>
                <?php if(Auth::guest() && !Session::has('guest_id')): ?>
                <?php if(Session::has('nickError')): ?>       
                    <div class="alert alert-danger errors">
                        <strong>Warning!</strong> <?php echo session('nickError'); ?>

                    </div>        
                <?php endif; ?>
                <div class="welcome">
                    <p class="welcome_message">Welcome</p>
                    <p class="enter_nickname">Sing in to start chat with your friends or enter you nickname and:</p>
                    <div class="nick_input">
                        <div class="prefix">
                            <span class="enter_nickname">Guest_</span>
                        </div>
                        <div class="input">
                            <?php echo e(Form::open(array('url' => 'signAsGuest'))); ?>

                            <div class="input-group">
                                <input type="text" class="form-control nickname" name="nickname" placeholder="Enter You Nickname">
                                <span class="input-group-btn">
                                    <button class="btn btn-primary" name="enter_to_chat" type="submit">Enter</button>
                                </span>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                        
                    </div>
                </div>
                <?php endif; ?>
                <div class="room_info">  
                    <div class="room_pic">
                        <?php if(isset($data)): ?>
                            <img src="/images/room_images/<?php echo e($data['room_info']->room_img); ?>" class="thumbnail">                            
                        <?php endif; ?>

                    </div>                    
                    <div class="active_users">
                        <?php if(isset($data)): ?>
                        <button class="active_usersbtn" style="display:block;"><?php echo e((count($data['onlineUsers']))+(count($data['onlineGuests']))); ?> User(s) Online</button>
                        <div class="dropdown-content">                            
                                <?php $__currentLoopData = $data['onlineUsers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>                                    
                                    <a href="#"><?php echo e($value->username); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php $__currentLoopData = $data['onlineGuests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>                                    
                                    <a href="#"><?php echo e($value->guestname); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                                            
                        </div>
                        <?php else: ?>
                        <button class="active_usersbtn" style="display:none;"></button>
                        <div class="dropdown-content">
                            
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="conversation">
                    <?php if(isset($data)): ?>
                        <?php $__currentLoopData = $data['result']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>                       
                            <?php if($value->username): ?>
                                <div class="message_container">
                                    <p class="sender_name"><?php echo e($value->username); ?></p>
                                    <p class="send_date"><?php echo e($value->time); ?></p>
                                    <p class="mess"><?php echo e($value->message); ?></p>
                                </div>                                
                            <?php else: ?>
                                <div class="message_container">
                                    <p class="sender_name"><?php echo e($value->guestname); ?></p>
                                    <p class="send_date"><?php echo e($value->time); ?></p>
                                    <p class="mess"><?php echo e($value->message); ?></p>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                        
                    <?php endif; ?>
                </div>
                <?php if(isset($data)): ?>
                    
                <div class="send_messages">
                    <div class="input-group">
                        <input type="text" class="form-control sms" placeholder="Enter Text Message">
                        <span class="input-group-btn">
                            <button class="btn btn-primary send_button" value="<?php echo e($data['room_info']->id); ?>" name="send_button" type="button">Send</button>
                        </span>
                    </div><!-- /input-group -->
                </div>
                <?php else: ?>
                <div class="send_messages" style="display: none;">
                    <div class="input-group">
                        <input type="text" class="form-control sms" placeholder="Enter Text Message">
                        <span class="input-group-btn">
                            <button class="btn btn-primary send_button" name="send_button" type="button">Send</button>
                        </span>
                    </div><!-- /input-group -->
                </div>                
                <?php endif; ?>                
            </div>
        </div>
        <!-- Modal -->
        <div id="addRoom" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <?php echo e(Form::open(array('url' => 'addRoom', 'files'=> 'true'))); ?>

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add Room</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="room_name">Enter Room Name</label>
                            <input type="text" name="room_name" class="form-control" id="room_name" required>
                        </div>
                        <div class="form-group">
                            <label for="sel1">Choose privacy level</label>
                            <select class="form-control" id="sel1" name="privacy_level" required>
                                <option value="" disabled selected>-- Choose level --</option>
                                <option value="0">Public</option>
                                <option value="1">Private</option>                               
                            </select>
                        </div>
                        <div class="form-group">
                            
                            <input type="checkbox" id="link_checkbox">
                            <label for="link_checkbox">Generate Link</label>
                            <input type="text" class="form-control" value="" id="link_generator" name="link_generator" readonly style="display :none;">
                            <input type="hidden" name="short_link" class="short_link">
                        </div>
                        <label class="btn btn-primary btn-file">
                            Choose Room Image <input type="file" name="file" style="display: none;">
                        </label>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary add_room_button" disabled>Add Room</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <script src="/js/app.js"></script>
        <script src="/js/script.js"></script>
    </body>
</html>
